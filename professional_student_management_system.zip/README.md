# Student Management System with 2FA

This is a professional student management system web app that features:
- Login authentication using Firebase
- Simulated Two-Factor Authentication (2FA)
- A modern dashboard for managing students

## Technologies Used
- HTML, CSS, JavaScript
- Firebase for authentication

## Setup
1. Replace `firebase-config.js` with your Firebase credentials.
2. Open `index.html` in a browser or host on GitHub Pages/Firebase Hosting.

---

**Designed for class presentation by Edna Nyokabi**
