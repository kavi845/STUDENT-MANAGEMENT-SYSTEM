function logout() {
  window.location.href = "index.html";
}
document.getElementById('student-form').addEventListener('submit', function(e) {
  e.preventDefault();
  const studentName = document.getElementById('student-name').value;
  const list = document.getElementById('student-list');
  const item = document.createElement('li');
  item.textContent = studentName;
  list.appendChild(item);
  this.reset();
});
